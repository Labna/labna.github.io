package nf.fr.labnaworlds;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.security.auth.login.AccountNotFoundException;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

/**
 *
 * @author Labna
 */
//@WebServlet(name = "HelloForm", urlPatterns = {"/HelloForm"}) // ici on peut definir la page de destination comme dans web.xml
public class HelloWorld extends HttpServlet {
  // invocation de la base de donnée mentionner dans context.xml
  @Resource(name = "jdbc/mkyongdb")
  private DataSource ds;
  // on crée l'objet qui nous servira de controleur pour les utilisateurs
  private PersonManager pm;

  private final Map<String, String> articles = Map.of("sport", "<h2>Sport</h2><h3>Coupe du monde de fosotball: victoire de la  France</h3>",
          "people", "<h2>People</h2><h3>La nouvelle tenue de Lady Gaga</h3>",
          "politique", "<h2>Politique</h2><h3>Élection européenne: décryptage</h3>",
          "science", "<h2>Science</h2><h3>Le moteur électrique qui promet: HET (hunstable electric turbine)</h3>");
 
  @Override
  public void init() throws ServletException {
    super.init(); //To change body of generated methods, choose Tools | Templates.
    // il nous faut récupèrer l'instance du Singleton PersonManager
    this.pm = PersonManager.getInstance();
  }

  /**
   * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
   * methods.
   *
   * @param request servlet request
   * @param response servlet response
   * @throws ServletException if a servlet-specific error occurs
   * @throws IOException if an I/O error occurs
   */
  protected void processRequest(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    Cookie[] cookies = request.getCookies();
    if (cookies != null) {
      for (Cookie cooky : cookies) {
        if ("name".equals(cooky.getName())) {
          request.setAttribute("name", cooky.getValue());
        }
        if (request.getAttribute("article") == null
                && "article".equals(cooky.getName())
                && cooky.getValue() != null) {
          request.setAttribute("article", cooky.getValue());
        }
      }
    }
    request.setAttribute("articles", articles);
    request.getRequestDispatcher("index.jsp").forward(request, response);
  }

  /**
   * Handles the HTTP <code>GET</code> method.
   *
   * @param request servlet request
   * @param response servlet response
   * @throws ServletException if a servlet-specific error occurs
   * @throws IOException if an I/O error occurs
   */
  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    String form = request.getParameter("formCat");
    if ("preference".equals(form)) { // si le formuaire "préférences" nous envoi des infos
      request.setAttribute("preference", true);
      if (request.getParameter("cat") != null) {
        request.setAttribute("article", request.getParameter("cat")); // le cookie n'existe pas encore dans request alors on l'ajoute pour être utiliser dans index.jsp
        Cookie cook = new Cookie("article", request.getParameter("cat"));
        cook.setMaxAge(24 * 3600);
        response.addCookie(cook);
        if (request.getSession().getAttribute("account") instanceof Person) { // instanceof, vérifie si not null et si bien une Person
          Person p = (Person) request.getSession().getAttribute("account");
          try {
            p.setFavouriteArticle(request.getParameter("cat"), ds);
          } catch (SQLException ex) {
            Logger.getLogger(HelloWorld.class.getName()).log(Level.SEVERE, null, ex);
          }
        }
      }
    }

    processRequest(request, response);
  }

  /**
   * Handles the HTTP <code>POST</code> method.
   *
   * @param request servlet request
   * @param response servlet response
   * @throws ServletException if a servlet-specific error occurs
   * @throws IOException if an I/O error occurs
   */
  @Override  
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    String form = request.getParameter("formCat");
    if ("login".equals(form)) { // si le formulaire "login" nous envois des infos
      request.setAttribute("login", true);
      if (request.getParameter("name") != null && request.getParameter("password") != null) {
        request.setAttribute("name", request.getParameter("name"));
        try {
          Person p = pm.login(ds, (String)request.getParameter("name"), (String)request.getParameter("password"));
          HttpSession ses = request.getSession(true);
          ses.setAttribute("account", p);
        } catch (SQLException | AccountNotFoundException ex) {
          Logger.getLogger(HelloWorld.class.getName()).log(Level.SEVERE, null, ex);
          request.setAttribute("error", ex.toString());
        }      
      }
    }
    doGet(request, response);
  }

  /**
   * Returns a short description of the servlet.
   *
   * @return a String containing servlet description
   */
  @Override
  public String getServletInfo() {
    return "Short description";
  }

}
