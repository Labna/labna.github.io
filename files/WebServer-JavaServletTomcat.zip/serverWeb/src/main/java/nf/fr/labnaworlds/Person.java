/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nf.fr.labnaworlds;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Set;
import javax.sql.DataSource;

/**
 * The main an only interface to use to manage Users of the website
 * @author Labna
 */
public class Person implements Serializable {

  private final int id;
  private String name;
  private String password;
  private String lastSessionConnection;
  private String favouriteArticle;

  /**
   * This one works !
   * 
   * You have to be sure the ID exist into database
   * @param ds DataSource
   * @param id from the DataSource
   * @throws java.sql.SQLException
   */
  public Person(DataSource ds, int id) throws SQLException {
    Connection con = ds.getConnection();
    Statement stm = con.createStatement();
    String str = String.format("SELECT * FROM serverdata.user WHERE idUser=%d ;", id);
    try (ResultSet rs = stm.executeQuery(str)) {
      // permet de récupèrer le première element
      rs.next();
      
      name = rs.getString("name");
      password = rs.getString("password");
      lastSessionConnection = rs.getString("lastSessionConnection");
      favouriteArticle = rs.getString("favoriteArticle");
    }
    this.id = id;
  }

  /**
   * Doesn't work, dont use !
   * here for availability an usability of the class
   * @param name
   */
  public Person(String name) {
    this.name = name;
    id = 0;
  }

  /**
   * Doesn't work, don't use !
   * here for availability an usability of the class
   * @param name
   * @param password
   * @param lastSessionConnection
   * @param favouriteArticle
   */
  public Person(String name, String password, String lastSessionConnection, String favouriteArticle) {
    this.name = name;
    this.password = password;
    this.lastSessionConnection = lastSessionConnection;
    this.favouriteArticle = favouriteArticle;
    // set id
    // set Session to Blob

    this.id = 0;
  }

  /**
   * Doesn't work, don't use !
   * here for availability an usability of the class
   * @param id
   * @param name
   * @param password
   * @param lastSessionConnection
   * @param favouriteArticle
   */
  public Person(int id, String name, String password, String lastSessionConnection, String favouriteArticle) {
    this.id = id;
    this.name = name;
    this.password = password;
    this.lastSessionConnection = lastSessionConnection;
    this.favouriteArticle = favouriteArticle;
  }

  /**
   * Get the Map and send update to the database
   *
   * @param ds
   * @param map
   * @throws SQLException
   */
  private void updateDB(DataSource ds, Map<String, String> values) throws SQLException {
    try (Connection conn = ds.getConnection(); Statement stmt = conn.createStatement()) {
      // début de la chaine de requête
      String updateUser = "UPDATE `serverdata`.`user` SET ";
      lastSessionConnection = LocalDateTime.now().toString();
      Set<String> keys = values.keySet();
      for (String key : keys) {
        updateUser += String.format("`%s`='%s', ", key, values.get(key));
      }
      // updateUser = updateUser.substring(0, updateUser.length() - 2); // supprime les derniers ", "
      // Logger.getLogger(Person.class.getName()).log(Level.SEVERE, String.format("`%s`='%s' ", "lastSessionConnection", lastSessionConnection.toString()));
      
      // on récupère la date/heure afin de mettre à jours la dernière connection
      updateUser += String.format("`%s`='%s' ", "lastSessionConnection", lastSessionConnection);
      updateUser += String.format("WHERE (`idUser` = '%d');", id);

      //ce qui génère updateUser= "UPDATE `serverdata`.`user` SET `name`='Alban', `lastSessionConnection`='2019-12-31 12:59:59' WHERE (`idUser` = '1');"
      stmt.executeUpdate(updateUser);
    }
  }

  /**
   * Change the name in the object and in the database
   * @param name
   * @param ds
   * @throws SQLException
   */
  public void setName(String name, DataSource ds) throws SQLException {
    this.name = name;
    updateDB(ds, Map.of("name", name));
  }

  public String getName() {
    return name;
  }

  public int getId() {
    return id;
  }

  public String getPassword() {
    return password;
  }

  /**
   * Change the password in the object and in the database
   * @param password
   * @param ds
   * @throws SQLException
   */
  public void setPassword(String password, DataSource ds) throws SQLException {
    this.password = password;
    updateDB(ds, Map.of("password", password));
  }

  public String getFavouriteArticle() {
    return favouriteArticle;
  }

  /**
   * Change the favouriteArticle in the object and in the database
   * @param favouriteArticle
   * @param ds
   * @throws SQLException
   */
  public void setFavouriteArticle(String favouriteArticle, DataSource ds) throws SQLException {
    this.favouriteArticle = favouriteArticle;
    updateDB(ds, Map.of("favoriteArticle", favouriteArticle));
  }

  public String getLastSessionConnection() {
    return lastSessionConnection;
  }

}
