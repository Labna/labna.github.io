/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nf.fr.labnaworlds;

import java.sql.Timestamp;

/**
 *
 * @author Labna
 */
public class PersonBuilder {

    private String name;
    private String password;
    private String lastSessionConnection;
    private String favouriteArticle;

    public PersonBuilder() {

    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getFavouriteArticle() {
        return favouriteArticle;
    }

    public String getLastSessionConnection() {
        return lastSessionConnection;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setFavouriteArticle(String favouriteArticle) {
        this.favouriteArticle = favouriteArticle;
    }

    public void setLastSessionConnection(String lastSessionConnection) {
        this.lastSessionConnection = lastSessionConnection;
    }
}
