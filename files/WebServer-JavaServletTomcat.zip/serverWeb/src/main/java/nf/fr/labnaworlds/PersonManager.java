/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nf.fr.labnaworlds;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.security.auth.login.AccountNotFoundException;
import javax.sql.DataSource;

/**
 *
 * @author Labna
 */
public class PersonManager {

  // ici commence la transformation de la class en Singleton
  private PersonManager() {
  }

  private static final PersonManager INSTANCE = new PersonManager();
  
  public static PersonManager getInstance(){
    return INSTANCE;
  }
  // avec les éléments précédents on fait en sorte que cette classe soit un Singleton
  
  /**
   *
   * @param ds
   * @param userName
   * @param password
   * @return
   * @throws SQLException
   * @throws AccountNotFoundException
   */
  public Person login(DataSource ds, String userName, String password) throws SQLException, AccountNotFoundException {
    Connection conn = ds.getConnection();
    Statement stmt = conn.createStatement();
    ResultSet rs = stmt.executeQuery(String.format("SELECT * FROM serverdata.user WHERE name ='%s' and password='%s';", userName, password));
    if (rs.next()) {
      return new Person(rs.getInt("idUser"), rs.getString("name"), rs.getString("password"), rs.getString("lastSessionConnection"), rs.getString("favoriteArticle"));
    } else {
      throw new AccountNotFoundException("No account found with this login/password.");
    }
  }

  /**
   * Get List of Ids from Database, form administrator only
   *
   * @param ds DataSource
   * @return ArrayList of Integer
   * @throws SQLException
   */
  public ArrayList<Integer> getPersonIdList(DataSource ds) throws SQLException {
    Connection con = ds.getConnection();
    Statement stm = con.createStatement();
    String str = "SELECT idUser FROM serverdata.user;";
    ArrayList<Integer> list;
    try (ResultSet rs = stm.executeQuery(str)) {
      list = new ArrayList<>();
      while (rs.next()) {
        list.add(rs.getInt("idUser"));
      }
    }
    return list;
  }

  /**
   * For Admin only, perfect fit with getPersonIdList()
   *
   * @param ds
   * @param list
   * @return ArrayList of Person
   * @throws java.sql.SQLException
   */
  public ArrayList<Person> getPersonList(DataSource ds, ArrayList<Integer> list) throws SQLException {
    ArrayList<Person> persons = new ArrayList<>();
    for (Integer integer : list) {
      persons.add(new Person(ds, integer));
    }
    return persons;
  }

  public PersonBuilder PersonBuilder() {
    return new PersonBuilder();
  }

  public Person personFinilize(PersonBuilder pb) {
    return new Person(pb.getName(), pb.getPassword(), pb.getLastSessionConnection(), pb.getFavouriteArticle());
  }
}
